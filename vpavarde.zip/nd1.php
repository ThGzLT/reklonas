<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>pirmas tinklapis</title>
    
   
</head>
<body>
<?php
echo "hello world one";
echo "hello world one";
echo "hello world one";
echo "hello world one";
echo "pasaulis keturi";
?>