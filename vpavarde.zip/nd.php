<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>pirmas tinklapis</title>
    
   
</head>
<body>
<?php
echo "hello world";
echo "hello world 2x";
echo "hello world vienas world";
echo "trecias pakeitimas";
?>